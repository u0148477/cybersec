import os

with open('flag.txt') as file:
    m1 = file.read().strip().encode()
m2 = b'I can\'t believe that no one has thought of this scheme yet'

k = os.urandom(len(m1))

def xor(bytes1, bytes2):
    return bytes(a1 ^ a2 for a1, a2 in zip(bytes1, bytes2))

c1 = xor(m1, k)
c2 = xor(m2, k[1:] + k[:1])

with open('chal.txt', 'w') as file:
    file.write(f'{int.from_bytes(c1, "big")}\n')
    file.write(f'{int.from_bytes(c2, "big")}\n')
