package main

import (
	"fmt"
	"net/http"
	"strings"

	"github.com/dreadl0ck/tlsx"
	"github.com/wi1dcard/fingerproxy/pkg/ja3"
	"github.com/wi1dcard/fingerproxy/pkg/ja4"
	"github.com/wi1dcard/fingerproxy/pkg/metadata"
)

func http_method(method string) string {
	return strings.ToLower(method)[:2]
}

func http_version(version string) string {
	v := strings.Split(version, "/")
	if len(v) == 2 {
		if v[1] == "2" || v[1] == "2.0" {
			return "20"
		}
	}

	return "11"
}

func hasCookie(req *http.Request) string {
	if len(req.Cookies()) > 0 {
		return "c"
	}
	return "n"
}

func hasReferer(referer string) string {
	if referer != "" {
		return "r"
	}
	return "n"
}

func num_headers(headers http.Header, host string) int {
	len_headers := len(headers)
	// net/http doesn't include the Host header in the headers list
	// https://blog.stigok.com/2021/11/16/go-incoming-http-request-host-header-gone.html
	if host != "" {
		len_headers++
	}
	if headers.Get("Cookie") != "" {
		len_headers--
	}
	if headers.Get("Referer") != "" {
		len_headers--
	}
	return len_headers
}

func language(headers http.Header) string {
	lan := headers.Get("Accept-Language")
	if lan != "" {
		clean := strings.ReplaceAll(lan, "-", "")
		lower := strings.ToLower(clean)
		first := strings.Split(lower, ",")[0] + "0000"
		return first[:4]
	}
	return "0000"
}

// 1. HTTP Method, GET="ge", PUT="pu", POST="po", etc.
// 2. HTTP Version, 2.0="20", 1.1="11"
// 3. Cookie, if there's a Cookie "c", if no Cookie "n"
// 4. Referer, if there's a Referer "r", if no Referer "n"
// 5. Number of HTTP Headers (ignore Cookie and Referer)
// 6. First 4 characters of primary Accept-Language (0000 if no Accept-Language)
func fingerprintJA4H_a(req *http.Request) string {
	method := http_method(req.Method)
	version := http_version(req.Proto)
	cookie := hasCookie(req)
	referer := hasReferer(req.Referer())
	num_headers := num_headers(req.Header, req.Host)
	accept_lang := language(req.Header)

	return fmt.Sprintf("%s%s%s%s%02d%s", method, version, cookie, referer, num_headers, accept_lang)
}

func fingerprintJA3(data *metadata.Metadata) (string, error) {
	fp := &tlsx.ClientHelloBasic{}
	err := fp.Unmarshal(data.ClientHelloRecord)

	ja3Raw := ja3.Bare(fp)
	JA3 := ja3.BareToDigestHex(ja3Raw)

	return JA3, err
}

func fingerprintJA4(data *metadata.Metadata) (string, error) {
	fp := &ja4.JA4Fingerprint{}
	err := fp.UnmarshalBytes(data.ClientHelloRecord, 't')

	JA4 := fp.String()

	return JA4, err
}

func fingerprintHTTP2(data *metadata.Metadata) string {
	protocol := data.ConnectionState.NegotiatedProtocol

	if protocol == "h2" {
		HTTP2 := data.HTTP2Frames.String()
		return HTTP2
	} else {
		return ""
	}
}
