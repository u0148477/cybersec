package main

import (
	"bufio"
	"context"
	"crypto/tls"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"github.com/KeithAlt/go-cert-generator/pkg/gencert"
	"github.com/wi1dcard/fingerproxy/pkg/proxyserver"
)

var (
	tlsConf *tls.Config

	ctx, _ = signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
)

func main() {
	setupTLSConfig()

	run()
}

func httpLogger() *log.Logger {
	_, verbosePresent := os.LookupEnv("VERBOSE")
	pr, pw := io.Pipe()
	logger := log.New(pw, "http: ", log.LstdFlags|log.Lmsgprefix|log.Lmicroseconds)
	scanner := bufio.NewScanner(pr)
	go func() {
		for scanner.Scan() {
			go func(line string) {
				if verbosePresent {
					fmt.Fprintln(os.Stdout, line)
				}
			}(scanner.Text())
		}
	}()
	return logger
}

func getEnv(key, fallback string) string {
	if value, ok := os.LookupEnv(key); ok {
		return value
	}
	return fallback
}

func setupTLSConfig() {
	tlsConf = &tls.Config{
		NextProtos: []string{"h2", "http/1.1"},
	}

	cert, err := gencert.Generate()
	if err != nil {
		panic(err)
	}
	certificatePath := cert.PemPath
	certificateKeyPath := cert.KeyPath

	tlsCert, err := tls.LoadX509KeyPair(certificatePath, certificateKeyPath)
	if err != nil {
		panic(err)
	}

	tlsConf.Certificates = []tls.Certificate{tlsCert}
}

func run() {
	listenAddr := ":" + getEnv("PORT", "8443")

	// create proxyserver
	server := proxyserver.NewServer(ctx, http.HandlerFunc(flagServer), tlsConf)
	server.ErrorLog = httpLogger()

	// listen and serve
	log.Printf("server listening on %s", listenAddr)
	err := server.ListenAndServe(listenAddr)
	log.Fatal(err)
}
