import os
import random

FLAG = os.getenv('FLAG')
assert len(FLAG) <= 50

def set_state(r, state):
    r.setstate((3, tuple(state) + (624,), None))

r = random.Random()
set_state(r, [ord(c) for c in FLAG] + [0 for _ in range(624 - len(FLAG))])
for _ in range(100):
    r.getrandbits(10_000_000)
    set_state(r, [r.getrandbits(32) for _ in range(624)])

with open('output.txt', 'w+') as file: file.write(hex(r.getrandbits(5_000))[2:])
