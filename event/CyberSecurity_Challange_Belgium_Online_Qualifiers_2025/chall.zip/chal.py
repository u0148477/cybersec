import base64
from Crypto.Cipher import AES
import secrets

FLAG = open('flag.txt').read().strip()


class PRNG:
    """
        Highly simple and secure generator of pseudo-random numbers between 0 and 1102, inclusive
    """
    def __init__(self, seed):
        self.state = seed

    def __next__(self):
        self.state += 1
        return pow(self.state, self.state, 1103)

def pad(string):
    return string.ljust(((len(string) - 1) // 16 + 1) * 16).encode()


prng = PRNG(secrets.randbits(256))

open('numbers.txt', 'w+').write('\n'.join([str(next(prng)) for _ in range(20)]))

key = b''.join([(next(prng) % 256).to_bytes(1, 'big') for _ in range(32)])
ciphertext = AES.new(key, AES.MODE_ECB).encrypt(pad(FLAG))

open('chal.txt', 'w+').write(base64.b64encode(ciphertext).decode())
