import random

from Crypto.Cipher import AES

def xor(bytes1, bytes2):
    return bytes(a1 ^ a2 for a1, a2 in zip(bytes1, bytes2))

def encrypt(flag, keys):
    """
    `flag`: A string to encrypt
    `keys`: A list of 16 `bytes` objects, each 16 bytes long

    Output: A list of nonces and a list of ciphertexts
    """
    c = []
    nonces = []
    for i, char in enumerate(flag):
        nonce = random.getrandbits(16*8).to_bytes(16, 'big')
        nonces.append(nonce)
        c.append(xor(nonce, b"\0" * 15 + char.encode()))
        for j in range(i % 16 + 1):
            if random.random() < 0.5:
                c[-1] = xor(c[-1], keys[j])
            else:
                c[-1] = AES.new(keys[j], AES.MODE_ECB).encrypt(c[-1])
    
    return nonces, c
