#!/bin/sh

qemu-arm -plugin ./libfilter.so -L . ./chall
